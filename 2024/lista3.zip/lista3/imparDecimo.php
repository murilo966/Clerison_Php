<?php
$a = 1;
while ($a <= 10) {
    $impar = $a%2;
    if ($impar != 0) {
        echo $a;
    }
    $a++;
}


?>