<?php

$a = 1;
while ($a <= 10) {
    $par = $a%2;
    if ($par === 0) {
        echo $a;
    }
    $a = $a+1;
}


?>