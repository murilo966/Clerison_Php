<?php
for ($i=100; $i >= 1; $i = $i-2) { 
    echo "$i <br>";
}

?>