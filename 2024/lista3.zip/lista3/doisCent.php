<?php
for ($i=1; $i <= 100; $i = $i+2) { 
    echo "$i <br>";
}


?>